# Migração da Base de Dados MySQL do WordPress
#
# Gerado: Monday 20. September 2021 19:26 UTC
# Nome do Servidor: db:3306
# Banco de Dados: `wordpress`
# URL: //showanatureliving.com.br
# Path: //showanatureliving.com.br
# Tables: wp_commentmeta, wp_comments, wp_db7_forms, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, customize_changeset, page, post, wpcf7_contact_form
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Apagar qualquer tabela `wp_commentmeta` existente
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Estrutura da tabela `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_commentmeta`
#

#
# Fim do conteúdo da tabela `wp_commentmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_comments` existente
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Estrutura da tabela `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Um comentarista do WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-09-13 14:29:40', '2021-09-13 17:29:40', 'Olá, isso é um comentário.\nPara começar a moderar, editar e excluir comentários, visite a tela de Comentários no painel.\nAvatares de comentaristas vêm a partir do <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# Fim do conteúdo da tabela `wp_comments`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_db7_forms` existente
#

DROP TABLE IF EXISTS `wp_db7_forms`;


#
# Estrutura da tabela `wp_db7_forms`
#

CREATE TABLE `wp_db7_forms` (
  `form_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_post_id` bigint(20) NOT NULL,
  `form_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `form_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_db7_forms`
#

#
# Fim do conteúdo da tabela `wp_db7_forms`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_links` existente
#

DROP TABLE IF EXISTS `wp_links`;


#
# Estrutura da tabela `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_links`
#

#
# Fim do conteúdo da tabela `wp_links`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_options` existente
#

DROP TABLE IF EXISTS `wp_options`;


#
# Estrutura da tabela `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=245 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', '//showanatureliving.com.br', 'yes'),
(2, 'home', '//showanatureliving.com.br', 'yes'),
(3, 'blogname', 'Showa', 'yes'),
(4, 'blogdescription', 'Nature Living', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'elias@aldeiaconteudo.com.br', 'yes'),
(7, 'start_of_week', '0', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j \\d\\e F \\d\\e Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'j \\d\\e F \\d\\e Y, H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:94:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=10&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:33:"classic-editor/classic-editor.php";i:2;s:36:"contact-form-7/wp-contact-form-7.php";i:3;s:42:"contact-form-cfdb7/contact-form-cfdb-7.php";i:4;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'showa', 'yes'),
(41, 'stylesheet', 'showa', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', 'America/Sao_Paulo', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '10', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '8', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1647106180', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '49752', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:12:"cfdb7_access";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'pt_BR', 'yes'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:156:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Posts recentes</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:224:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Comentários</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Arquivos</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categorias</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(105, 'cron', 'a:6:{i:1631554182;a:6:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1631554189;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1631554193;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1631554249;a:1:{s:28:"wp_update_comment_type_batch";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1631640582;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(128, 'can_compress_scripts', '0', 'no'),
(141, 'recently_activated', 'a:0:{}', 'yes'),
(148, 'theme_mods_twentytwentyone', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1631726123;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(151, 'current_theme', 'showa', 'yes'),
(152, 'theme_mods_showa', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:11:"custom_logo";i:7;}', 'yes'),
(153, 'theme_switched', '', 'yes'),
(159, 'category_children', 'a:0:{}', 'yes'),
(161, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(162, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(167, 'site_logo', '7', 'yes'),
(168, 'recovery_mode_email_last_sent', '1631730819', 'yes'),
(169, 'recovery_keys', 'a:1:{s:22:"NAgCUxX3L3Pye1DrK0pPvn";a:2:{s:10:"hashed_key";s:34:"$P$B6XssdoIJZRriwCcoFaXMdg3TK8kv0.";s:10:"created_at";i:1631730819;}}', 'yes'),
(183, 'wpcf7', 'a:2:{s:7:"version";s:5:"5.4.2";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1631761492;s:7:"version";s:5:"5.4.2";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(184, 'cfdb7_view_install_date', '2021-09-16 3:04:56', 'yes'),
(187, 'acf_version', '5.10.2', 'yes'),
(188, 'options_redes_sociais_0_titulo', 'Instagram', 'no'),
(189, '_options_redes_sociais_0_titulo', 'field_6144da4b414af', 'no'),
(190, 'options_redes_sociais_0_url', '#', 'no'),
(191, '_options_redes_sociais_0_url', 'field_6144da5e414b0', 'no'),
(192, 'options_redes_sociais_0_icone', '<i class="fab fa-instagram"></i>', 'no'),
(193, '_options_redes_sociais_0_icone', 'field_6144da66414b1', 'no'),
(194, 'options_redes_sociais_1_titulo', 'LinkedIn', 'no'),
(195, '_options_redes_sociais_1_titulo', 'field_6144da4b414af', 'no'),
(196, 'options_redes_sociais_1_url', '#', 'no'),
(197, '_options_redes_sociais_1_url', 'field_6144da5e414b0', 'no'),
(198, 'options_redes_sociais_1_icone', '<i class="fab fa-linkedin-in"></i>', 'no'),
(199, '_options_redes_sociais_1_icone', 'field_6144da66414b1', 'no'),
(200, 'options_redes_sociais_2_titulo', 'Facebook', 'no'),
(201, '_options_redes_sociais_2_titulo', 'field_6144da4b414af', 'no'),
(202, 'options_redes_sociais_2_url', '#', 'no'),
(203, '_options_redes_sociais_2_url', 'field_6144da5e414b0', 'no'),
(204, 'options_redes_sociais_2_icone', '<i class="fab fa-facebook-f"></i>', 'no'),
(205, '_options_redes_sociais_2_icone', 'field_6144da66414b1', 'no'),
(206, 'options_redes_sociais_3_titulo', 'Youtube', 'no'),
(207, '_options_redes_sociais_3_titulo', 'field_6144da4b414af', 'no'),
(208, 'options_redes_sociais_3_url', '#', 'no'),
(209, '_options_redes_sociais_3_url', 'field_6144da5e414b0', 'no'),
(210, 'options_redes_sociais_3_icone', '<i class="fab fa-youtube"></i>', 'no'),
(211, '_options_redes_sociais_3_icone', 'field_6144da66414b1', 'no'),
(218, 'options_redes_sociais', '4', 'no'),
(219, '_options_redes_sociais', 'field_6144da38414ae', 'no'),
(244, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1632165975;}', 'no') ;

#
# Fim do conteúdo da tabela `wp_options`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_postmeta` existente
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Estrutura da tabela `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(9, 7, '_wp_attached_file', '2021/09/logo-showa.png'),
(10, 7, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:250;s:6:"height";i:75;s:4:"file";s:22:"2021/09/logo-showa.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"logo-showa-150x75.png";s:5:"width";i:150;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(11, 8, '_wp_attached_file', '2021/09/cropped-logo-showa.png'),
(12, 8, '_wp_attachment_context', 'site-icon'),
(13, 8, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:30:"2021/09/cropped-logo-showa.png";s:5:"sizes";a:6:{s:6:"medium";a:4:{s:4:"file";s:30:"cropped-logo-showa-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:30:"cropped-logo-showa-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-270";a:4:{s:4:"file";s:30:"cropped-logo-showa-270x270.png";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-192";a:4:{s:4:"file";s:30:"cropped-logo-showa-192x192.png";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-180";a:4:{s:4:"file";s:30:"cropped-logo-showa-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";}s:12:"site_icon-32";a:4:{s:4:"file";s:28:"cropped-logo-showa-32x32.png";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(14, 9, '_wp_trash_meta_status', 'publish'),
(15, 9, '_wp_trash_meta_time', '1631730668'),
(16, 10, '_edit_last', '1'),
(17, 10, '_wp_page_template', 'front-page.php'),
(18, 10, '_edit_lock', '1631906224:1'),
(19, 12, '_form', '[text* nome class:form-control placeholder "Nome"]\n\n<div class="group-input">\n<div>\n[email* email class:form-control placeholder "E-mail"]\n</div>\n<div>\n[tel* telefone class:form-control placeholder "Celular"]\n</div>\n</div>\n\n[textarea* mensagem class:form-control placeholder "Mensagem"]\n\n[submit class:btn-default "Entrar em contato"]'),
(20, 12, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:28:"[_site_title] - Contato site";s:6:"sender";s:23:"[_site_title] <[email]>";s:9:"recipient";s:19:"[_site_admin_email]";s:4:"body";s:161:"De: [nome] <[email]>\nTelefone: [telefone]\n\nCorpo da mensagem:\n[mensagem]\n\n-- \nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])";s:18:"additional_headers";s:17:"Reply-To: [email]";s:11:"attachments";s:0:"";s:8:"use_html";b:1;s:13:"exclude_blank";b:0;}'),
(21, 12, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:43:"[_site_title] <elias@aldeiaconteudo.com.br>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:122:"Corpo da mensagem:\n[your-message]\n\n-- \nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])";s:18:"additional_headers";s:29:"Reply-To: [_site_admin_email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(22, 12, '_messages', 'a:22:{s:12:"mail_sent_ok";s:27:"Agradecemos a sua mensagem.";s:12:"mail_sent_ng";s:74:"Ocorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.";s:16:"validation_error";s:63:"Um ou mais campos possuem um erro. Verifique e tente novamente.";s:4:"spam";s:74:"Ocorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.";s:12:"accept_terms";s:72:"Você deve aceitar os termos e condições antes de enviar sua mensagem.";s:16:"invalid_required";s:24:"O campo é obrigatório.";s:16:"invalid_too_long";s:23:"O campo é muito longo.";s:17:"invalid_too_short";s:23:"O campo é muito curto.";s:13:"upload_failed";s:49:"Ocorreu um erro desconhecido ao enviar o arquivo.";s:24:"upload_file_type_invalid";s:59:"Você não tem permissão para enviar esse tipo de arquivo.";s:21:"upload_file_too_large";s:26:"O arquivo é muito grande.";s:23:"upload_failed_php_error";s:36:"Ocorreu um erro ao enviar o arquivo.";s:12:"invalid_date";s:34:"O formato de data está incorreto.";s:14:"date_too_early";s:44:"A data é anterior à mais antiga permitida.";s:13:"date_too_late";s:44:"A data é posterior à maior data permitida.";s:14:"invalid_number";s:34:"O formato de número é inválido.";s:16:"number_too_small";s:46:"O número é menor do que o mínimo permitido.";s:16:"number_too_large";s:46:"O número é maior do que o máximo permitido.";s:23:"quiz_answer_not_correct";s:39:"A resposta para o quiz está incorreta.";s:13:"invalid_email";s:45:"O endereço de e-mail informado é inválido.";s:11:"invalid_url";s:19:"A URL é inválida.";s:11:"invalid_tel";s:35:"O número de telefone é inválido.";}'),
(23, 12, '_additional_settings', ''),
(24, 12, '_locale', 'pt_BR'),
(25, 13, '_edit_last', '1'),
(26, 13, '_edit_lock', '1631913006:1'),
(27, 32, '_edit_last', '1'),
(28, 32, '_edit_lock', '1631902442:1'),
(29, 38, '_wp_attached_file', '2021/09/img-destaque-showa.png'),
(30, 38, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1013;s:6:"height";i:598;s:4:"file";s:30:"2021/09/img-destaque-showa.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:30:"img-destaque-showa-300x177.png";s:5:"width";i:300;s:6:"height";i:177;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:30:"img-destaque-showa-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:30:"img-destaque-showa-768x453.png";s:5:"width";i:768;s:6:"height";i:453;s:9:"mime-type";s:9:"image/png";}s:9:"post-blog";a:4:{s:4:"file";s:30:"img-destaque-showa-430x250.png";s:5:"width";i:430;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(31, 10, '_thumbnail_id', '38'),
(32, 10, 'banner_principal', '2'),
(33, 10, '_banner_principal', 'field_6144d6ebfb986'),
(34, 10, 'video', ''),
(35, 10, '_video', 'field_6144d751fb989'),
(36, 10, 'titulo_galeria', 'Conecte-se com as facilidades da<br> cidade e com o equilíbrio da natureza.'),
(37, 10, '_titulo_galeria', 'field_6144d921ef6bd'),
(38, 10, 'texto_destaque_detalhes', '<h2>Projetado para você ter tudo aquilo que melhora o seu ser.</h2>\r\n<ul>\r\n 	<li>4 suítes</li>\r\n 	<li>126 unidades de 152 a 161m<sup>2</sup></li>\r\n 	<li>336 vagas de garagem residenciais</li>\r\n 	<li>Próximo à praia, shopping e Terceira Ponte</li>\r\n 	<li>12 lojas no térreo com área total de 2.063m<sup>2</sup></li>\r\n 	<li>18 vagas de garagem comerciais.</li>\r\n</ul>'),
(39, 10, '_texto_destaque_detalhes', 'field_6144d78bc096d'),
(40, 10, 'items_detalhes', '4'),
(41, 10, '_items_detalhes', 'field_6144d7bec096e'),
(42, 10, 'titulo_arquitetos', 'Um empreendimento inovador, idealizado por mentes transformadoras.'),
(43, 10, '_titulo_arquitetos', 'field_6144d82e1e495'),
(44, 10, 'lista_arquitetos', '3'),
(45, 10, '_lista_arquitetos', 'field_6144d8471e496'),
(46, 39, '_wp_attached_file', '2021/09/banner-1.jpg'),
(47, 39, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:880;s:4:"file";s:20:"2021/09/banner-1.jpg";s:5:"sizes";a:6:{s:6:"medium";a:4:{s:4:"file";s:20:"banner-1-300x138.jpg";s:5:"width";i:300;s:6:"height";i:138;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"banner-1-1024x469.jpg";s:5:"width";i:1024;s:6:"height";i:469;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"banner-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"banner-1-768x352.jpg";s:5:"width";i:768;s:6:"height";i:352;s:9:"mime-type";s:10:"image/jpeg";}s:9:"1536x1536";a:4:{s:4:"file";s:21:"banner-1-1536x704.jpg";s:5:"width";i:1536;s:6:"height";i:704;s:9:"mime-type";s:10:"image/jpeg";}s:9:"post-blog";a:4:{s:4:"file";s:20:"banner-1-430x250.jpg";s:5:"width";i:430;s:6:"height";i:250;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(48, 40, '_wp_attached_file', '2021/09/banner-2.jpg'),
(49, 40, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:880;s:4:"file";s:20:"2021/09/banner-2.jpg";s:5:"sizes";a:6:{s:6:"medium";a:4:{s:4:"file";s:20:"banner-2-300x138.jpg";s:5:"width";i:300;s:6:"height";i:138;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"banner-2-1024x469.jpg";s:5:"width";i:1024;s:6:"height";i:469;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:20:"banner-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"banner-2-768x352.jpg";s:5:"width";i:768;s:6:"height";i:352;s:9:"mime-type";s:10:"image/jpeg";}s:9:"1536x1536";a:4:{s:4:"file";s:21:"banner-2-1536x704.jpg";s:5:"width";i:1536;s:6:"height";i:704;s:9:"mime-type";s:10:"image/jpeg";}s:9:"post-blog";a:4:{s:4:"file";s:20:"banner-2-430x250.jpg";s:5:"width";i:430;s:6:"height";i:250;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(50, 10, 'banner_principal_0_imagem', '39'),
(51, 10, '_banner_principal_0_imagem', 'field_6144d6fcfb987'),
(52, 10, 'banner_principal_1_imagem', '40'),
(53, 10, '_banner_principal_1_imagem', 'field_6144d6fcfb987'),
(54, 10, 'items_detalhes_0_titulo', 'Lazer'),
(55, 10, '_items_detalhes_0_titulo', 'field_6144d7d4c096f'),
(56, 10, 'items_detalhes_0_lista_detalhes', '<ul>\r\n 	<li>Academia</li>\r\n 	<li>Área para jogos eletrônicos e de mesa</li>\r\n 	<li>Cozinha experimental</li>\r\n 	<li>Piscina e sauna</li>\r\n 	<li>Quadra poliesportiva grande</li>\r\n</ul>'),
(57, 10, '_items_detalhes_0_lista_detalhes', 'field_6144d7d9c0970'),
(58, 10, 'items_detalhes_1_titulo', 'Segurança'),
(59, 10, '_items_detalhes_1_titulo', 'field_6144d7d4c096f'),
(60, 10, 'items_detalhes_1_lista_detalhes', '<ul>\r\n 	<li>Controle de acesso através de pulmão de seguir</li>\r\n 	<li>Área de logística para delivery</li>\r\n</ul>'),
(61, 10, '_items_detalhes_1_lista_detalhes', 'field_6144d7d9c0970'),
(62, 10, 'items_detalhes_2_titulo', 'Comodidade'),
(63, 10, '_items_detalhes_2_titulo', 'field_6144d7d4c096f'),
(64, 10, 'items_detalhes_2_lista_detalhes', '<ul>\r\n 	<li>Coworking</li>\r\n 	<li>Spa</li>\r\n 	<li>Espaços de beleza feminina e masculina</li>\r\n 	<li>Espaço para vending machine</li>\r\n 	<li>Wi-fi em toda a área do condomínio</li>\r\n</ul>'),
(65, 10, '_items_detalhes_2_lista_detalhes', 'field_6144d7d9c0970'),
(66, 10, 'items_detalhes_3_titulo', 'Humanização'),
(67, 10, '_items_detalhes_3_titulo', 'field_6144d7d4c096f'),
(68, 10, 'items_detalhes_3_lista_detalhes', '<ul>\r\n 	<li>Valorização da iluminação e ventilação natural</li>\r\n 	<li>Áreas abertas para leitura e atividades físicas ao ar livre</li>\r\n 	<li>Espaços destinados à espiritualidade</li>\r\n 	<li>Plantas personalizadas</li>\r\n</ul>'),
(69, 10, '_items_detalhes_3_lista_detalhes', 'field_6144d7d9c0970'),
(70, 41, '_wp_attached_file', '2021/09/arkteto.png'),
(71, 41, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:288;s:6:"height";i:220;s:4:"file";s:19:"2021/09/arkteto.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"arkteto-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(72, 42, '_wp_attached_file', '2021/09/davi.png'),
(73, 42, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:288;s:6:"height";i:220;s:4:"file";s:16:"2021/09/davi.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"davi-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(74, 43, '_wp_attached_file', '2021/09/hanazaki.png'),
(75, 43, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:288;s:6:"height";i:220;s:4:"file";s:20:"2021/09/hanazaki.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"hanazaki-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(76, 10, 'lista_arquitetos_0_foto', '42'),
(77, 10, '_lista_arquitetos_0_foto', 'field_6144d8561e497'),
(78, 10, 'lista_arquitetos_0_nome', 'David Bastos Arquitetos'),
(79, 10, '_lista_arquitetos_0_nome', 'field_6144d8651e498'),
(80, 10, 'lista_arquitetos_0_descricao', 'David Bastos é um arquiteto e decorador de estilo apurado que possui escritórios em Salvador e São Paulo. Ao reunir elegância e sutileza em seus trabalhos, David conquistou reconhecimento nacional e internacional. Para ele, o conforto e a informalidade são as palavras-chave de um bom trabalho. Que, agora, chega à Vila Velha materializado no Showa.'),
(81, 10, '_lista_arquitetos_0_descricao', 'field_6144d86a1e499'),
(82, 10, 'lista_arquitetos_1_foto', '43'),
(83, 10, '_lista_arquitetos_1_foto', 'field_6144d8561e497'),
(84, 10, 'lista_arquitetos_1_nome', 'Hanazaki Paisagismo'),
(85, 10, '_lista_arquitetos_1_nome', 'field_6144d8651e498'),
(86, 10, 'lista_arquitetos_1_descricao', 'lex Hanazaki é considerado um dos grandes nomes do paisagismo contemporâneo brasileiro. Comandando um premiado escritório em São Paulo, apontado como um dos mais criativos escritórios de arquitetura externa do Brasil, considera paisagismo qualidade de vida. Criar jardins como obras de arte é seu desafio. Com um parceiro como Hanazaki, não há dúvida de que o Showa terá ambientes incomparáveis no estado.'),
(87, 10, '_lista_arquitetos_1_descricao', 'field_6144d86a1e499'),
(88, 10, 'lista_arquitetos_2_foto', '41'),
(89, 10, '_lista_arquitetos_2_foto', 'field_6144d8561e497'),
(90, 10, 'lista_arquitetos_2_nome', 'Arkteto Projeto e Planejamento'),
(91, 10, '_lista_arquitetos_2_nome', 'field_6144d8651e498'),
(92, 10, 'lista_arquitetos_2_descricao', 'Kennedy Vianna é o arquiteto proprietário do ateliê Arkteto Projeto e Planejamento. Vianna cria e desenvolve grandes negócios, com foco na viabilidade e estruturação imobiliária. Dentre os ambientes projetados por ele estão centros comerciais, escritórios, residências, hotéis, estacionamentos e instalações desportivas. Agora, ele também ajudará a fazer do Showa um marco na arquitetura capixaba.'),
(93, 10, '_lista_arquitetos_2_descricao', 'field_6144d86a1e499'),
(94, 48, '_wp_attached_file', '2021/09/slide-1.jpg'),
(95, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1357;s:6:"height";i:566;s:4:"file";s:19:"2021/09/slide-1.jpg";s:5:"sizes";a:5:{s:6:"medium";a:4:{s:4:"file";s:19:"slide-1-300x125.jpg";s:5:"width";i:300;s:6:"height";i:125;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"slide-1-1024x427.jpg";s:5:"width";i:1024;s:6:"height";i:427;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:19:"slide-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"slide-1-768x320.jpg";s:5:"width";i:768;s:6:"height";i:320;s:9:"mime-type";s:10:"image/jpeg";}s:9:"post-blog";a:4:{s:4:"file";s:19:"slide-1-430x250.jpg";s:5:"width";i:430;s:6:"height";i:250;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(96, 10, 'areascomuns_0_titulo', 'Áreas comuns'),
(97, 10, '_areascomuns_0_titulo', 'field_6144e1c674901'),
(98, 10, 'areascomuns_0_fotos_areas_comuns_0_imagem_areas_comuns', '48'),
(99, 10, '_areascomuns_0_fotos_areas_comuns_0_imagem_areas_comuns', 'field_6144e25674903'),
(100, 10, 'areascomuns_0_fotos_areas_comuns_1_imagem_areas_comuns', '48'),
(101, 10, '_areascomuns_0_fotos_areas_comuns_1_imagem_areas_comuns', 'field_6144e25674903'),
(102, 10, 'areascomuns_0_fotos_areas_comuns_2_imagem_areas_comuns', '48'),
(103, 10, '_areascomuns_0_fotos_areas_comuns_2_imagem_areas_comuns', 'field_6144e25674903'),
(104, 10, 'areascomuns_0_fotos_areas_comuns', '3'),
(105, 10, '_areascomuns_0_fotos_areas_comuns', 'field_6144e20b74902'),
(106, 10, 'areascomuns', '1'),
(107, 10, '_areascomuns', 'field_6144e14474900'),
(108, 10, 'fotos_areas_comuns_0_lista_fotos', '48') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(109, 10, '_fotos_areas_comuns_0_lista_fotos', 'field_6144e3290eaa8'),
(110, 10, 'fotos_areas_comuns', '2'),
(111, 10, '_fotos_areas_comuns', 'field_6144e31d0eaa7'),
(112, 10, 'fotos_areas_comuns_1_lista_fotos', '48'),
(113, 10, '_fotos_areas_comuns_1_lista_fotos', 'field_6144e3290eaa8'),
(114, 10, 'fotos_areas_privativa_0_lista_fotos', '48'),
(115, 10, '_fotos_areas_privativa_0_lista_fotos', 'field_6144e3f7adeec'),
(116, 10, 'fotos_areas_privativa_1_lista_fotos', '48'),
(117, 10, '_fotos_areas_privativa_1_lista_fotos', 'field_6144e3f7adeec'),
(118, 10, 'fotos_areas_privativa', '2'),
(119, 10, '_fotos_areas_privativa', 'field_6144e3f7adeeb'),
(120, 10, 'fotos_plantas_0_lista_fotos', '48'),
(121, 10, '_fotos_plantas_0_lista_fotos', 'field_6144e405adeee'),
(122, 10, 'fotos_plantas_1_lista_fotos', '48'),
(123, 10, '_fotos_plantas_1_lista_fotos', 'field_6144e405adeee'),
(124, 10, 'fotos_plantas', '2'),
(125, 10, '_fotos_plantas', 'field_6144e405adeed'),
(126, 10, 'fotos_localizacao_0_lista_fotos', '48'),
(127, 10, '_fotos_localizacao_0_lista_fotos', 'field_6144e415adef0'),
(128, 10, 'fotos_localizacao_1_lista_fotos', '48'),
(129, 10, '_fotos_localizacao_1_lista_fotos', 'field_6144e415adef0'),
(130, 10, 'fotos_localizacao', '2'),
(131, 10, '_fotos_localizacao', 'field_6144e415adeef') ;

#
# Fim do conteúdo da tabela `wp_postmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_posts` existente
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Estrutura da tabela `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-09-13 14:29:40', '2021-09-13 17:29:40', '<!-- wp:paragraph -->\n<p>Boas-vindas ao WordPress. Esse é o seu primeiro post. Edite-o ou exclua-o, e então comece a escrever!</p>\n<!-- /wp:paragraph -->', 'Olá, mundo!', '', 'publish', 'open', 'open', '', 'ola-mundo', '', '', '2021-09-13 14:29:40', '2021-09-13 17:29:40', '', 0, '//showanatureliving.com.br/?p=1', 0, 'post', '', 1),
(4, 1, '2021-09-13 14:29:53', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-09-13 14:29:53', '0000-00-00 00:00:00', '', 0, '//showanatureliving.com.br/?p=4', 0, 'post', '', 0),
(7, 1, '2021-09-15 15:30:43', '2021-09-15 18:30:43', '', 'logo-showa', '', 'inherit', 'open', 'closed', '', 'logo-showa', '', '', '2021-09-15 15:30:43', '2021-09-15 18:30:43', '', 0, '//showanatureliving.com.br/wp-content/uploads/2021/09/logo-showa.png', 0, 'attachment', 'image/png', 0),
(8, 1, '2021-09-15 15:31:05', '2021-09-15 18:31:05', '//showanatureliving.com.br/wp-content/uploads/2021/09/cropped-logo-showa.png', 'cropped-logo-showa.png', '', 'inherit', 'open', 'closed', '', 'cropped-logo-showa-png', '', '', '2021-09-15 15:31:05', '2021-09-15 18:31:05', '', 0, '//showanatureliving.com.br/wp-content/uploads/2021/09/cropped-logo-showa.png', 0, 'attachment', 'image/png', 0),
(9, 1, '2021-09-15 15:31:08', '2021-09-15 18:31:08', '{"blogdescription":{"value":"Nature Living","type":"option","user_id":1,"date_modified_gmt":"2021-09-15 18:31:08"},"site_icon":{"value":8,"type":"option","user_id":1,"date_modified_gmt":"2021-09-15 18:31:08"},"showa::custom_logo":{"value":7,"type":"theme_mod","user_id":1,"date_modified_gmt":"2021-09-15 18:31:08"}}', '', '', 'trash', 'closed', 'closed', '', 'e95d4197-1393-464b-b582-c8c40bc8c855', '', '', '2021-09-15 15:31:08', '2021-09-15 18:31:08', '', 0, '//showanatureliving.com.br/e95d4197-1393-464b-b582-c8c40bc8c855/', 0, 'customize_changeset', '', 0),
(10, 1, '2021-09-15 15:43:43', '2021-09-15 18:43:43', '<h2>Reinvente a sua forma de viver, conviver e compartilhar.</h2>\r\nO Showa é um empreendimento residencial de 4 suítes, onde o paisagismo, as áreas comuns e cada espaço interno e externo valorizam a essência humana.\r\n\r\nUm verdadeiro oásis urbano, localizado em uma região privilegiada da Praia da Costa, em Vila Velha: a cidade que respira qualidade de vida.\r\n\r\nEsse projeto sem igual no Espírito Santo, batizado com o conceito de Nature Living, foi desenhado para quem busca conforto e comodidade, por meio do bem-estar, afeto e felicidade.\r\n\r\nViver em harmonia é uma escolha.\r\nConheça o Showa Nature Living e faça a sua!', 'Showa', '', 'publish', 'closed', 'closed', '', 'showa', '', '', '2021-09-17 16:11:32', '2021-09-17 19:11:32', '', 0, '//showanatureliving.com.br/?page_id=10', 0, 'page', '', 0),
(11, 1, '2021-09-15 15:43:43', '2021-09-15 18:43:43', '', 'Showa', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2021-09-15 15:43:43', '2021-09-15 18:43:43', '', 10, '//showanatureliving.com.br/?p=11', 0, 'revision', '', 0),
(12, 1, '2021-09-16 00:04:52', '2021-09-16 03:04:52', '[text* nome class:form-control placeholder "Nome"]\r\n\r\n<div class="group-input">\r\n<div>\r\n[email* email class:form-control placeholder "E-mail"]\r\n</div>\r\n<div>\r\n[tel* telefone class:form-control placeholder "Celular"]\r\n</div>\r\n</div>\r\n\r\n[textarea* mensagem class:form-control placeholder "Mensagem"]\r\n\r\n[submit class:btn-default "Entrar em contato"]\n1\n[_site_title] - Contato site\n[_site_title] <[email]>\n[_site_admin_email]\nDe: [nome] <[email]>\r\nTelefone: [telefone]\r\n\r\nCorpo da mensagem:\r\n[mensagem]\r\n\r\n-- \r\nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])\nReply-To: [email]\n\n1\n\n\n[_site_title] "[your-subject]"\n[_site_title] <elias@aldeiaconteudo.com.br>\n[your-email]\nCorpo da mensagem:\r\n[your-message]\r\n\r\n-- \r\nEste e-mail foi enviado de um formulário de contato em [_site_title] ([_site_url])\nReply-To: [_site_admin_email]\n\n\n\nAgradecemos a sua mensagem.\nOcorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.\nUm ou mais campos possuem um erro. Verifique e tente novamente.\nOcorreu um erro ao tentar enviar sua mensagem. Tente novamente mais tarde.\nVocê deve aceitar os termos e condições antes de enviar sua mensagem.\nO campo é obrigatório.\nO campo é muito longo.\nO campo é muito curto.\nOcorreu um erro desconhecido ao enviar o arquivo.\nVocê não tem permissão para enviar esse tipo de arquivo.\nO arquivo é muito grande.\nOcorreu um erro ao enviar o arquivo.\nO formato de data está incorreto.\nA data é anterior à mais antiga permitida.\nA data é posterior à maior data permitida.\nO formato de número é inválido.\nO número é menor do que o mínimo permitido.\nO número é maior do que o máximo permitido.\nA resposta para o quiz está incorreta.\nO endereço de e-mail informado é inválido.\nA URL é inválida.\nO número de telefone é inválido.', 'Formulário de contato', '', 'publish', 'closed', 'closed', '', 'formulario-de-contato-1', '', '', '2021-09-16 00:08:19', '2021-09-16 03:08:19', '', 0, '//showanatureliving.com.br/?post_type=wpcf7_contact_form&#038;p=12', 0, 'wpcf7_contact_form', '', 0),
(13, 1, '2021-09-17 14:59:19', '2021-09-17 17:59:19', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"10";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'HOME', 'home', 'publish', 'closed', 'closed', '', 'group_6144d6c5c15a9', '', '', '2021-09-17 15:55:55', '2021-09-17 18:55:55', '', 0, '//showanatureliving.com.br/?post_type=acf-field-group&#038;p=13', 0, 'acf-field-group', '', 0),
(14, 1, '2021-09-17 14:59:19', '2021-09-17 17:59:19', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'BANNER', 'banner', 'publish', 'closed', 'closed', '', 'field_6144d6d5fb985', '', '', '2021-09-17 14:59:19', '2021-09-17 17:59:19', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=14', 0, 'acf-field', '', 0),
(15, 1, '2021-09-17 14:59:19', '2021-09-17 17:59:19', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Banner principal', 'banner_principal', 'publish', 'closed', 'closed', '', 'field_6144d6ebfb986', '', '', '2021-09-17 14:59:19', '2021-09-17 17:59:19', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=15', 1, 'acf-field', '', 0),
(16, 1, '2021-09-17 14:59:19', '2021-09-17 17:59:19', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Imagem', 'imagem', 'publish', 'closed', 'closed', '', 'field_6144d6fcfb987', '', '', '2021-09-17 14:59:19', '2021-09-17 17:59:19', '', 15, '//showanatureliving.com.br/?post_type=acf-field&p=16', 0, 'acf-field', '', 0),
(17, 1, '2021-09-17 14:59:19', '2021-09-17 17:59:19', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'VIDEO', 'video', 'publish', 'closed', 'closed', '', 'field_6144d714fb988', '', '', '2021-09-17 14:59:19', '2021-09-17 17:59:19', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=17', 2, 'acf-field', '', 0),
(18, 1, '2021-09-17 14:59:19', '2021-09-17 17:59:19', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:3;s:9:"new_lines";s:0:"";}', 'Vídeo', 'video', 'publish', 'closed', 'closed', '', 'field_6144d751fb989', '', '', '2021-09-17 14:59:19', '2021-09-17 17:59:19', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=18', 3, 'acf-field', '', 0),
(19, 1, '2021-09-17 15:01:46', '2021-09-17 18:01:46', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'DETALHES', 'detalhes', 'publish', 'closed', 'closed', '', 'field_6144d77dc096c', '', '', '2021-09-17 15:52:08', '2021-09-17 18:52:08', '', 13, '//showanatureliving.com.br/?post_type=acf-field&#038;p=19', 6, 'acf-field', '', 0),
(20, 1, '2021-09-17 15:01:46', '2021-09-17 18:01:46', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:0;s:5:"delay";i:0;}', 'Texto de destaque', 'texto_destaque_detalhes', 'publish', 'closed', 'closed', '', 'field_6144d78bc096d', '', '', '2021-09-17 15:52:08', '2021-09-17 18:52:08', '', 13, '//showanatureliving.com.br/?post_type=acf-field&#038;p=20', 7, 'acf-field', '', 0),
(21, 1, '2021-09-17 15:01:46', '2021-09-17 18:01:46', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Items de detalhes', 'items_detalhes', 'publish', 'closed', 'closed', '', 'field_6144d7bec096e', '', '', '2021-09-17 15:52:08', '2021-09-17 18:52:08', '', 13, '//showanatureliving.com.br/?post_type=acf-field&#038;p=21', 8, 'acf-field', '', 0),
(22, 1, '2021-09-17 15:01:46', '2021-09-17 18:01:46', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'titulo', 'publish', 'closed', 'closed', '', 'field_6144d7d4c096f', '', '', '2021-09-17 15:01:46', '2021-09-17 18:01:46', '', 21, '//showanatureliving.com.br/?post_type=acf-field&p=22', 0, 'acf-field', '', 0),
(23, 1, '2021-09-17 15:01:46', '2021-09-17 18:01:46', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:35:"Criar o conteúdo em forma de lista";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:0;s:5:"delay";i:0;}', 'Lista de detalhes', 'lista_detalhes', 'publish', 'closed', 'closed', '', 'field_6144d7d9c0970', '', '', '2021-09-17 15:01:46', '2021-09-17 18:01:46', '', 21, '//showanatureliving.com.br/?post_type=acf-field&p=23', 1, 'acf-field', '', 0),
(24, 1, '2021-09-17 15:04:13', '2021-09-17 18:04:13', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'ARQUITETOS', 'arquitetos', 'publish', 'closed', 'closed', '', 'field_6144d80d1e494', '', '', '2021-09-17 15:52:08', '2021-09-17 18:52:08', '', 13, '//showanatureliving.com.br/?post_type=acf-field&#038;p=24', 9, 'acf-field', '', 0),
(25, 1, '2021-09-17 15:04:13', '2021-09-17 18:04:13', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'titulo_arquitetos', 'publish', 'closed', 'closed', '', 'field_6144d82e1e495', '', '', '2021-09-17 15:52:08', '2021-09-17 18:52:08', '', 13, '//showanatureliving.com.br/?post_type=acf-field&#038;p=25', 10, 'acf-field', '', 0),
(26, 1, '2021-09-17 15:04:13', '2021-09-17 18:04:13', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"block";s:12:"button_label";s:0:"";}', 'Lista de arquitetos', 'lista_arquitetos', 'publish', 'closed', 'closed', '', 'field_6144d8471e496', '', '', '2021-09-17 15:52:08', '2021-09-17 18:52:08', '', 13, '//showanatureliving.com.br/?post_type=acf-field&#038;p=26', 11, 'acf-field', '', 0),
(27, 1, '2021-09-17 15:04:13', '2021-09-17 18:04:13', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Foto', 'foto', 'publish', 'closed', 'closed', '', 'field_6144d8561e497', '', '', '2021-09-17 15:04:13', '2021-09-17 18:04:13', '', 26, '//showanatureliving.com.br/?post_type=acf-field&p=27', 0, 'acf-field', '', 0),
(28, 1, '2021-09-17 15:04:13', '2021-09-17 18:04:13', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Nome', 'nome', 'publish', 'closed', 'closed', '', 'field_6144d8651e498', '', '', '2021-09-17 15:04:13', '2021-09-17 18:04:13', '', 26, '//showanatureliving.com.br/?post_type=acf-field&p=28', 1, 'acf-field', '', 0),
(29, 1, '2021-09-17 15:04:13', '2021-09-17 18:04:13', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:6;s:9:"new_lines";s:2:"br";}', 'Descrição', 'descricao', 'publish', 'closed', 'closed', '', 'field_6144d86a1e499', '', '', '2021-09-17 15:04:13', '2021-09-17 18:04:13', '', 26, '//showanatureliving.com.br/?post_type=acf-field&p=29', 2, 'acf-field', '', 0),
(30, 1, '2021-09-17 15:06:53', '2021-09-17 18:06:53', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'GALERIA', 'galeria', 'publish', 'closed', 'closed', '', 'field_6144d916ef6bc', '', '', '2021-09-17 15:06:53', '2021-09-17 18:06:53', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=30', 4, 'acf-field', '', 0),
(31, 1, '2021-09-17 15:06:53', '2021-09-17 18:06:53', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'titulo_galeria', 'publish', 'closed', 'closed', '', 'field_6144d921ef6bd', '', '', '2021-09-17 15:06:53', '2021-09-17 18:06:53', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=31', 5, 'acf-field', '', 0),
(32, 1, '2021-09-17 15:12:05', '2021-09-17 18:12:05', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:5:"geral";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Informações', 'informacoes', 'publish', 'closed', 'closed', '', 'group_6144da282c233', '', '', '2021-09-17 15:12:12', '2021-09-17 18:12:12', '', 0, '//showanatureliving.com.br/?post_type=acf-field-group&#038;p=32', 0, 'acf-field-group', '', 0),
(33, 1, '2021-09-17 15:12:05', '2021-09-17 18:12:05', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"block";s:12:"button_label";s:0:"";}', 'Redes sociais', 'redes_sociais', 'publish', 'closed', 'closed', '', 'field_6144da38414ae', '', '', '2021-09-17 15:12:12', '2021-09-17 18:12:12', '', 32, '//showanatureliving.com.br/?post_type=acf-field&#038;p=33', 0, 'acf-field', '', 0),
(34, 1, '2021-09-17 15:12:05', '2021-09-17 18:12:05', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'titulo', 'publish', 'closed', 'closed', '', 'field_6144da4b414af', '', '', '2021-09-17 15:12:05', '2021-09-17 18:12:05', '', 33, '//showanatureliving.com.br/?post_type=acf-field&p=34', 0, 'acf-field', '', 0),
(35, 1, '2021-09-17 15:12:05', '2021-09-17 18:12:05', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'URL', 'url', 'publish', 'closed', 'closed', '', 'field_6144da5e414b0', '', '', '2021-09-17 15:12:05', '2021-09-17 18:12:05', '', 33, '//showanatureliving.com.br/?post_type=acf-field&p=35', 1, 'acf-field', '', 0),
(36, 1, '2021-09-17 15:12:05', '2021-09-17 18:12:05', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Ícone', 'icone', 'publish', 'closed', 'closed', '', 'field_6144da66414b1', '', '', '2021-09-17 15:12:05', '2021-09-17 18:12:05', '', 33, '//showanatureliving.com.br/?post_type=acf-field&p=36', 2, 'acf-field', '', 0),
(37, 1, '2021-09-17 15:21:02', '2021-09-17 18:21:02', '<h2>Reinvente a sua forma de viver, conviver e compartilhar.</h2>\nO Showa é um empreendimento residencial de 4 suítes, onde o paisagismo, as áreas comuns e cada espaço interno e externo valorizam a essência humana.\n\nUm verdadeiro oásis urbano, localizado em uma região privilegiada da Praia da Costa, em Vila Velha: a cidade que respira qualidade de vida.\n\nEsse projeto sem igual no Espírito Santo, batizado com o conceito de Nature Living, foi desenhado para quem busca conforto e comodidade, por meio do bem-estar, afeto e felicidade.\n\nViver em harmonia é uma escolha.\nConheça o Showa Nature Living e faça a sua!', 'Showa', '', 'inherit', 'closed', 'closed', '', '10-autosave-v1', '', '', '2021-09-17 15:21:02', '2021-09-17 18:21:02', '', 10, '//showanatureliving.com.br/?p=37', 0, 'revision', '', 0),
(38, 1, '2021-09-17 15:22:03', '2021-09-17 18:22:03', '', 'img-destaque-showa', '', 'inherit', 'open', 'closed', '', 'img-destaque-showa', '', '', '2021-09-17 15:22:03', '2021-09-17 18:22:03', '', 10, '//showanatureliving.com.br/wp-content/uploads/2021/09/img-destaque-showa.png', 0, 'attachment', 'image/png', 0),
(39, 1, '2021-09-17 15:22:43', '2021-09-17 18:22:43', '', 'banner-1', '', 'inherit', 'open', 'closed', '', 'banner-1', '', '', '2021-09-17 15:22:43', '2021-09-17 18:22:43', '', 10, '//showanatureliving.com.br/wp-content/uploads/2021/09/banner-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(40, 1, '2021-09-17 15:22:45', '2021-09-17 18:22:45', '', 'banner-2', '', 'inherit', 'open', 'closed', '', 'banner-2', '', '', '2021-09-17 15:22:45', '2021-09-17 18:22:45', '', 10, '//showanatureliving.com.br/wp-content/uploads/2021/09/banner-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2021-09-17 15:25:46', '2021-09-17 18:25:46', '', '_arkteto', '', 'inherit', 'open', 'closed', '', '_arkteto', '', '', '2021-09-17 15:25:46', '2021-09-17 18:25:46', '', 10, '//showanatureliving.com.br/wp-content/uploads/2021/09/arkteto.png', 0, 'attachment', 'image/png', 0),
(42, 1, '2021-09-17 15:25:46', '2021-09-17 18:25:46', '', '_davi', '', 'inherit', 'open', 'closed', '', '_davi', '', '', '2021-09-17 15:25:46', '2021-09-17 18:25:46', '', 10, '//showanatureliving.com.br/wp-content/uploads/2021/09/davi.png', 0, 'attachment', 'image/png', 0),
(43, 1, '2021-09-17 15:25:47', '2021-09-17 18:25:47', '', '_hanazaki', '', 'inherit', 'open', 'closed', '', '_hanazaki', '', '', '2021-09-17 15:25:47', '2021-09-17 18:25:47', '', 10, '//showanatureliving.com.br/wp-content/uploads/2021/09/hanazaki.png', 0, 'attachment', 'image/png', 0),
(48, 1, '2021-09-17 15:47:05', '2021-09-17 18:47:05', '', 'slide-1', '', 'inherit', 'open', 'closed', '', 'slide-1', '', '', '2021-09-17 15:47:05', '2021-09-17 18:47:05', '', 10, '//showanatureliving.com.br/wp-content/uploads/2021/09/slide-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(49, 1, '2021-09-17 15:50:01', '2021-09-17 18:50:01', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Fotos - Áreas comuns', 'fotos_areas_comuns', 'publish', 'closed', 'closed', '', 'field_6144e31d0eaa7', '', '', '2021-09-17 15:55:55', '2021-09-17 18:55:55', '', 13, '//showanatureliving.com.br/?post_type=acf-field&#038;p=49', 13, 'acf-field', '', 0),
(50, 1, '2021-09-17 15:50:01', '2021-09-17 18:50:01', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Lista de fotos', 'lista_fotos', 'publish', 'closed', 'closed', '', 'field_6144e3290eaa8', '', '', '2021-09-17 15:50:24', '2021-09-17 18:50:24', '', 49, '//showanatureliving.com.br/?post_type=acf-field&#038;p=50', 0, 'acf-field', '', 0),
(51, 1, '2021-09-17 15:52:08', '2021-09-17 18:52:08', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'ÁREAS COMUNS', 'areas_comuns', 'publish', 'closed', 'closed', '', 'field_6144e3c764f19', '', '', '2021-09-17 15:52:08', '2021-09-17 18:52:08', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=51', 12, 'acf-field', '', 0),
(52, 1, '2021-09-17 15:55:55', '2021-09-17 18:55:55', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'ÁREAS PRIVATIVAS', '_copiar', 'publish', 'closed', 'closed', '', 'field_6144e495adef1', '', '', '2021-09-17 15:55:55', '2021-09-17 18:55:55', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=52', 14, 'acf-field', '', 0),
(53, 1, '2021-09-17 15:55:55', '2021-09-17 18:55:55', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Fotos - Áreas privativa', 'fotos_areas_privativa', 'publish', 'closed', 'closed', '', 'field_6144e3f7adeeb', '', '', '2021-09-17 15:55:55', '2021-09-17 18:55:55', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=53', 15, 'acf-field', '', 0),
(54, 1, '2021-09-17 15:55:55', '2021-09-17 18:55:55', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:0:"";s:12:"preview_size";s:4:"full";s:7:"library";s:0:"";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Lista de fotos', 'lista_fotos', 'publish', 'closed', 'closed', '', 'field_6144e3f7adeec', '', '', '2021-09-17 15:55:55', '2021-09-17 18:55:55', '', 53, '//showanatureliving.com.br/?post_type=acf-field&p=54', 0, 'acf-field', '', 0),
(55, 1, '2021-09-17 15:55:55', '2021-09-17 18:55:55', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'PLANTAS', '_copiar2', 'publish', 'closed', 'closed', '', 'field_6144e4a7adef2', '', '', '2021-09-17 15:55:55', '2021-09-17 18:55:55', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=55', 16, 'acf-field', '', 0),
(56, 1, '2021-09-17 15:55:55', '2021-09-17 18:55:55', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Fotos - Plantas', 'fotos_plantas', 'publish', 'closed', 'closed', '', 'field_6144e405adeed', '', '', '2021-09-17 15:55:55', '2021-09-17 18:55:55', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=56', 17, 'acf-field', '', 0),
(57, 1, '2021-09-17 15:55:55', '2021-09-17 18:55:55', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:0:"";s:12:"preview_size";s:4:"full";s:7:"library";s:0:"";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Lista de fotos', 'lista_fotos', 'publish', 'closed', 'closed', '', 'field_6144e405adeee', '', '', '2021-09-17 15:55:55', '2021-09-17 18:55:55', '', 56, '//showanatureliving.com.br/?post_type=acf-field&p=57', 0, 'acf-field', '', 0),
(58, 1, '2021-09-17 15:55:55', '2021-09-17 18:55:55', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'LOCALIZAÇÃO', '_copiar3', 'publish', 'closed', 'closed', '', 'field_6144e4b0adef3', '', '', '2021-09-17 15:55:55', '2021-09-17 18:55:55', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=58', 18, 'acf-field', '', 0),
(59, 1, '2021-09-17 15:55:55', '2021-09-17 18:55:55', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Fotos - Localização', 'fotos_localizacao', 'publish', 'closed', 'closed', '', 'field_6144e415adeef', '', '', '2021-09-17 15:55:55', '2021-09-17 18:55:55', '', 13, '//showanatureliving.com.br/?post_type=acf-field&p=59', 19, 'acf-field', '', 0),
(60, 1, '2021-09-17 15:55:55', '2021-09-17 18:55:55', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Lista de fotos', 'lista_fotos', 'publish', 'closed', 'closed', '', 'field_6144e415adef0', '', '', '2021-09-17 15:55:55', '2021-09-17 18:55:55', '', 59, '//showanatureliving.com.br/?post_type=acf-field&p=60', 0, 'acf-field', '', 0) ;

#
# Fim do conteúdo da tabela `wp_posts`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_term_relationships` existente
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Estrutura da tabela `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0) ;

#
# Fim do conteúdo da tabela `wp_term_relationships`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_term_taxonomy` existente
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Estrutura da tabela `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1) ;

#
# Fim do conteúdo da tabela `wp_term_taxonomy`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_termmeta` existente
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Estrutura da tabela `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_termmeta`
#

#
# Fim do conteúdo da tabela `wp_termmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_terms` existente
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Estrutura da tabela `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Sem categoria', 'sem-categoria', 0) ;

#
# Fim do conteúdo da tabela `wp_terms`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_usermeta` existente
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Estrutura da tabela `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'showa'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:"4160c6478f48d8c4575d950135f05f0eb56278b0837b70da853910d103e9e73a";a:4:{s:10:"expiration";i:1632338690;s:2:"ip";s:10:"172.18.0.1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.134 Safari/537.36";s:5:"login";i:1632165890;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:10:"172.18.0.0";}'),
(19, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(20, 1, 'metaboxhidden_dashboard', 'a:4:{i:0;s:21:"dashboard_site_health";i:1;s:18:"dashboard_activity";i:2;s:21:"dashboard_quick_press";i:3;s:17:"dashboard_primary";}'),
(21, 1, 'manageedit-pagecolumnshidden', 'a:1:{i:0;s:8:"comments";}'),
(22, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce&hidetb=1'),
(23, 1, 'wp_user-settings-time', '1631905852'),
(24, 1, 'wpcf7_hide_welcome_panel_on', 'a:1:{i:0;s:3:"5.4";}') ;

#
# Fim do conteúdo da tabela `wp_usermeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_users` existente
#

DROP TABLE IF EXISTS `wp_users`;


#
# Estrutura da tabela `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Conteúdo da tabela `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'showa', '$P$BtkGdMUhxfmpkTruwm/63qf/R8dDs71', 'showa', 'elias@aldeiaconteudo.com.br', '//showanatureliving.com.br', '2021-09-13 17:29:40', '', 0, 'showa') ;

#
# Fim do conteúdo da tabela `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

